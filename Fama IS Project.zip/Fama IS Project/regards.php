<!DOCTYPE html>

<html>
    <head>
        <meta name="viewport" content="width=device-width", initial-scale="1.0">
        <title>Thank you for being part of us </title>
        <link rel="stylesheet" href="style.css">

    </head>
    <body>
        <div class="header">
            <nav>
                <img style="height:50px ;width:100px;"src="logo.png" alt="logo">

               
            </nav>
            <div class="text-box">
                <h2>THANK YOU FOR BEING PART OF US </h2>
                <p>Connecting Farmers to the outside world</p>
                
                <button class="btn" onclick="window.location.href='index.php';">
                    Go back to home
                  </button>

            </div>

      


        </div>
    </body>
</html>