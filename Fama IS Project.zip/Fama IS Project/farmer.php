<html>
   <head>
      <title>Farmer</title>
      <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

   <nav>
      <img style="height:50px ;width:100px;"src="logo.png" alt="logo">

      <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="aboutus.php">About Us </a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="contactus.php">Contact Us</a></li>
          
      </ul>

  </nav>
   <div  style="position:relative;" class="container">
      <div class="login-box"  style="max-width:1000px;float:none;margin: 150px auto;"  >
      <div class="row">
         <div class ="col-md-6 login-left">
            <h2>Input Your Information Here </h2>
            <form action="connection.php" method="post">

               <div  class="form-group">


                  <label>Role</label>
                  <input type="text" name="user" class="form-control" required>

                  <label>Location</label>
                  <input type="text" name="user" class="form-control" required>

                  <label>Product</label>
                  <input type="text" name="user" class="form-control" required>

                  <label>Number </label>
                  <input type="text" name="user" class="form-control" required>

                 


               </div>

              
 
 <button type="submit" class="btn btn-primary" style="background-color: green">Submit </button><br><br>
 
            </form>

            

</div>

<div class ="col-md-6 login-right ">
   <a href="viewdata.php">
      
    


<button style="height:200px; background-color: green;" type="submit" class="btn btn-primary" onclick="window.location.href='regards.php';" >See information of other stakeholders in the region</button>
</a>


</div>



</div>




         </div>



      </div>
</div>






   </div>


</body>
      </html>
      
