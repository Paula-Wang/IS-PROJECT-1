<!DOCTYPE html>

<html>
    <head>
        <meta name="viewport" content="width=device-width", initial-scale="1.0">
        <title>FAMA website</title>
        <link rel="stylesheet" href="style.css">

    </head>
    <body>
        <div class="header">
            <nav>
                <img style="height:50px ;width:100px;"src="logo.png" alt="logo">

                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About Us </a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    
                </ul>

            </nav>
            <div class="text-box">
                <h1>FAMA FOR FARMERS</h1>
                <p>Connecting Farmers to the outside world</p>
                
                <button class="btn" onclick="window.location.href='login.php';">
                    Login
                  </button>

            </div>

      


        </div>
    </body>
</html>